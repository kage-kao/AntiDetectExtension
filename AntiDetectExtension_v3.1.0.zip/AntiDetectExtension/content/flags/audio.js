(self.__ade_flags||(self.__ade_flags={})).audio=1;
