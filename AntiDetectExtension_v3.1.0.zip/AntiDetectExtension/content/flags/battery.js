(self.__ade_flags||(self.__ade_flags={})).battery=1;
