(self.__ade_flags||(self.__ade_flags={})).fonts=1;
