(self.__ade_flags||(self.__ade_flags={})).sensors=1;
