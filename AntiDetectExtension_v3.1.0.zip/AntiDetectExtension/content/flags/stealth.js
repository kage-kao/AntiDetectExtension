(self.__ade_flags||(self.__ade_flags={})).stealth=1;
